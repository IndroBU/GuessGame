package xxxx;
import javax.swing.*;

public class AGui extends JFrame {
    public AGui() {
       
    }
    public static void main(String[] args) {
        AGui a = new AGui();
    }
}