package xxxx;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class GameFrame extends JFrame implements ActionListener {

	  public JLabel restartLbl;  
	  public JButton restartBtn;

	  public GameFrame() {

		restartLbl = new JLabel("New Game");
	    restartBtn = new JButton();

	    restartBtn.addActionListener(this);
	  }


	  public void actionPerformed1(ActionEvent e) {
	    if (e.getSource() == restartBtn) {
	    }
	  }


	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	}