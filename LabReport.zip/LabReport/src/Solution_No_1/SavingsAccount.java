package Solution_No_1;
import java.util.Scanner;
public class SavingsAccount {

	public static double ar=0.08;
	public double savingBalance;
	
	public void setsavingBalance(double x)
	{
		this.savingBalance=x;
	}
	
	public double calculateMonthlyInterest()
	{
		return (savingBalance*ar)/12.0;
	}
	public void setar(double x)
	{
		this.ar=x;
	}

     public static void main(String arg[])
      {
    	 SavingsAccount obj = new SavingsAccount();
    	 obj.setsavingBalance(54000.00);
    	 System.out.print("Monthly InterestSalary: ");
    	 System.out.println(obj.calculateMonthlyInterest());
    	 obj.setsavingBalance(55000.00);
    	 obj.setar(.1);
    	 System.out.print("NextMonth InterestSalary: ");
    	 System.out.println(obj.calculateMonthlyInterest()); 
    	 
     }
}
