package Chapter14;
import java.util.Scanner;
public class Displaying_String_in_Uppercase_and_LowerCase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	    int N=10;
	    if(N>5) System.out.println("N>5");
	    else if(N>5 && N>0) System.out.println("N>5 && N>0");

	}

}
