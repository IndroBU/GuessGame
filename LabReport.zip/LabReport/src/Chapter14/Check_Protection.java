package Chapter14;
import java.util.Scanner;
public class Check_Protection {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
      int P=0;	
      if(P==0) {P=1; 
      System.out.println("Yes");
      }
      else if(P==1)
      {
    	  System.out.println("No");
      }
	}
	

}
