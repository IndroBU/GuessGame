package Chapter14;
import java.util.StringTokenizer;
import java.util.Scanner;
public class Displaying_a_Sentence_with_its_Words_Reversed {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String input;
		Scanner sc = new Scanner(System.in);
		input= sc.nextLine();
		String Reverse_input="";
		StringTokenizer st = new StringTokenizer(input);
		while(st.hasMoreTokens())
		{
			Reverse_input =st.nextToken()+" "+Reverse_input;
		}
		System.out.println("Input : "+input);
		System.out.println("Revers_input_Tokenizer : "+Reverse_input);
		
	}

}
