package Chapter14;
import java.util.Scanner;
public class Searching_String {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Scanner sc = new Scanner(System.in);
       char[] chA;
       chA = new char[10];
      // chA = sc.nextLine();
       String s = sc.nextLine(); char c;
       s=s.toLowerCase();
       chA=s.toCharArray();
       System.out.println(chA);
       c=s.charAt(0);
       int ct=0,current=0;
       System.out.println(c);
       /*for(int i=0; i<s.length(); i++)
       {
    	 
    	 if(c==s.charAt(i))
    	 {
    		 ct++;
    		// System.out.println(i);
    	 }
    	   //System.out.println(s.indexOf('i'));
       }*/
       while(current!=-1)
       {
    	   current = s.indexOf(c,current+1);
    	   ct++;
       }
       System.out.println("First char in a string is: "+ct);
       
	}

}
