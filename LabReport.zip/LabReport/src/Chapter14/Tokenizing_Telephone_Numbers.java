package Chapter14;
import java.time.format.ResolverStyle;
import java.util.Scanner;
import java.util.StringTokenizer;
public class Tokenizing_Telephone_Numbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Scanner sc =new Scanner(System.in);
       System.out.println("Enter a sentence and press Enter: ");
       //Process user sentence
       String sentence = sc.nextLine();
      String[] tokens = sentence.split(",");
      System.out.printf("Number of elements: %d%n The Tokens are: %n",tokens.length);
      for(String token: tokens) System.out.println(token);
     // sentence.Reverese
      String Reverse;
      Reverse = new StringBuffer(sentence).reverse().toString();
      System.out.println(Reverse);
	}

}
