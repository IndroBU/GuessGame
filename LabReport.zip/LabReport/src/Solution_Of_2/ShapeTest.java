package Solution_Of_2;
public class ShapeTest
{
public static void main( String args[] )
{
Shape shapes[] = new Shape[3];
 shapes[0]= new Circle( 22, 88, 4 );
 shapes[1] = new Square( 71, 96, 10);
 shapes[2] = new Cube( 79, 61, 8 );
 
 for ( Shape currentShape : shapes )
 {
 //System.out.printf( "%s: %s",currentShape.getName(), currentShape );
 if ( currentShape instanceof TwoDimensionalShape )
 {
 TwoDimensionalShape twoDimensionalShape =( TwoDimensionalShape ) currentShape;
 System.out.printf( "%s's area is %s\n",
 currentShape.getName(), twoDimensionalShape.getArea() );
 
 }
  if( currentShape instanceof ThreeDimensionalShape)
  {
	  ThreeDimensionalShape threeDimensionalShape = (ThreeDimensionalShape) currentShape;
	  System.out.printf( "Shape Name : %s \n Area  is %s\n Volume is %s\n",
			  currentShape.getName(),threeDimensionalShape.getArea() , threeDimensionalShape.getVolume());
  }
 
 }

  
} 
} 
