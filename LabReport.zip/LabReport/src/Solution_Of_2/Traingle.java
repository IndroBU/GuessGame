package Solution_Of_2;

public class Traingle extends TwoDimensionalShape{
    
    private double base;
    private double height;
     
    public Traingle( double x, double y, double base, double height){
         
        super(x, y, base, height);
         
    
            this.base = base;
            this.height = height;
    
    } 
     
    public void setBase(double base){
      
        this.base = base;
    }
    public double getBase(){
        return base;
    }
    public void setHieght(double hieght){
     
        this.height = hieght;
    }
     
    public double getHieght(){
        return height;
    }
     
    public double getArea(){
        return (getBase()*getHieght()/2);
    } 
     
 
    @Override
    public String getName() {
        return ("Triangle"); //To change body of generated methods, choose Tools | Templates.
    }
         
}
