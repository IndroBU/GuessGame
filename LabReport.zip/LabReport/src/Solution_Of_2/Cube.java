package Solution_Of_2;
public class Cube extends ThreeDimensionalShape
{

	private double  Side;
public Cube( int x, int y, int side )
{
super( x, y, side, side, side );
   this.Side =side;
}
@Override
public double getArea()
{
	return 6*Side*Side;
}
@Override
public double getVolume()
{
	return Side*Side*Side;
}
@Override
public String getName() {
	
	return "Cube";
}
}
