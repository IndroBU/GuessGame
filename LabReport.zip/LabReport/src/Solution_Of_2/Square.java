package Solution_Of_2;

public class Square extends TwoDimensionalShape
{
     
    private double side;
     
     
    public Square( double x, double y, double side )
    {
        super( x, y, side, side );
         
    
             
            this.side = side;
       
    } 
     
    public void setSide(double side){
     
             
            this.side = side;
       
    }
     
    public double getSide(){
        return side;
    }
     @Override
    public double getArea(){
        return side * side;
    }
 
     
     
     
     
    @Override
    public String getName() {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    	return "Square";
    }
     
 
 
}
