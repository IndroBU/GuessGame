package Solution_Of_2;

public class Circle extends TwoDimensionalShape {
	 
    private double radius;
 
    public Circle(double x, double y, double radius){
         
        super(x, y, radius, radius);
         
    
             
            this.radius = radius;
        
    } 
     
 
    public double getRadius(){
     
        return radius;
    }
 
    public void setRadius(double newRadius){
 

    
             
            radius = radius;
        
    }
 
    @Override
    public double getArea() {
        return radius * radius * Math.PI;
    }
 
    @Override
    public String getName() {
         return "Circle"; //To change body of generated methods, choose Tools | Templates.
    }
 
     
}
