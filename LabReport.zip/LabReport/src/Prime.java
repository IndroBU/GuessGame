//import java.util.Arrays;
/**
 * A Simple Program That Sorts An Integer Array In Java.
 */
import static java.lang.Math.sqrt;
import static java.lang.Math.abs;
import java.util.Scanner;
public class Prime {

   public static void main(String[] args) {
     
	   int n, i, flag = 0;

	   
	    Scanner sc= new Scanner(System.in);
	    while(sc.hasNextLine()){
	    	
	       n=sc.nextInt();
   flag=0;
	    for(i=2; i<=n/2; ++i)
	    {
	        // condition for nonprime number
	        if(n%i==0)
	        {
	            flag=1;
	            break;
	        }
	    }

	    if (flag==0 &&n>1) 
	        System.out.printf("%d is a prime number.",n);
	    else
	        System.out.printf("%d is not a prime number.",n);
	    }
		
   }
}