package Exerceise9_8;
public class Quadrilateral {
Point point;

public Quadrilateral( int x0, int x1, int y0, int y1 ){
    point = new Point( x0, x1, y0, y1 );
}

protected int getDistanceX(){
    return point.getDistanceX();
}

protected  int getDistanceY(){
    return point.getDistanceX();
}


}
