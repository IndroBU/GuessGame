package Exerceise9_8;


public class SquareTesting {

public static void main(String[] orgs){
    Square sq = new Square( 5, 3, 5, 3 );
   if(sq.getArea()==4)
   {
	   System.out.println("YES, its a SQARE");
   }
   
}
}