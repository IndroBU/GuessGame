
package Exerceise9_8;
public class Point {
private int distanceX, distanceY;
private int x0, x1, y0, y1;

public Point( int x0, int x1, int y0, int y1 ){
    this.x0 = x0;
    this.x1 = x1;
    this.y0 = y0;
    this.y1 = y1;
    setDistanceX();
    setDistanceY();
}

private void setDistanceX(){
    distanceX = x1 - x0;
}

protected int getDistanceX(){
    return distanceX;
}

private void setDistanceY(){
    distanceY = y1 - y0;
}

protected int getDistanceY(){
    return distanceY;
}
}