
package Exerceise9_8;
public class Square extends Quadrilateral{
private int area;

public Square(int x0, int x1, int y0, int y1 ){
    super( x0, x1, y0, y1 );
    setArea();
}


protected void setArea() {
    area = super.getDistanceX() * super.getDistanceY();
}

public int getArea(){
    return area;
}
}
