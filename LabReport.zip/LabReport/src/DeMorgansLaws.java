import java.util.Scanner;
import static java.lang.Math.sqrt;
public class DeMorgansLaws {

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
	   boolean[] status;
	   int N= 100000000;
	   status = new boolean[N+1];
	   status[0]=true;
	    status[1]=true;
	    for(int i=4; i<=N; i+=2) status[i]=true;
	    for(int i=3; i<=sqrt(N); i+=2)
	    {
	    	if(status[i]==false){
	    	for(int j=i*i; j<=N; j+=i)
	    	{
	    		status[j]=true;
	    	}
	    	}
	    }
	    
	   

	  while(sc.hasNextLine())
	  {
		     int x;
		     x=sc.nextInt();
		     if(status[x]==false) 
		     {
		    	 System.out.println("Prime");
		     }
		     else 
		    	 System.out.println("Not Prime");
	  }

}
}

