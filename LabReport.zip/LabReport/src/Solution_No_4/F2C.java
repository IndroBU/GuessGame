package Solution_No_4;
import javax.swing.*;  
import java.util.Scanner;
import javax.swing.*;  
import java.awt.event.*;  
public class F2C implements ActionListener{  
    JTextField tf1,tf2,tf3;  
    JButton b1,b2;  
    F2C(){  
        JFrame f= new JFrame();  
        tf1=new JTextField();  
        tf1.setBounds(50,50,150,20);  
        tf3=new JTextField();  
        tf3.setBounds(50,150,150,20);  
        tf3.setEditable(false);   
        b1=new JButton("CALCULATE");  
        b1.setBounds(50,200,150,60);  
      
        b1.addActionListener(this);  
       
        f.add(tf1);
      
        f.add(tf3);
        f.add(b1);
        
        f.setSize(300,300);  
        f.setLayout(null);  
        f.setVisible(true);  
    }         
    public void actionPerformed(ActionEvent e) {  
        String s1=tf1.getText();  
 
        float F,C;
        F= Float.parseFloat(s1);
     
        C= (5 * (F-32)) / 9;
        String result=String.valueOf(C);  
        tf3.setText(result);  
    }  
public static void main(String[] args) {  
    new F2C();  
} } 
	