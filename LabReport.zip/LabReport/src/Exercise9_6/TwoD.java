package Exercise9_6;
import static java.lang.Math.sqrt;
public class TwoD extends Shape {
	public int  x1,y1,x2,y2;
	//public int x2,y2;
	public int AB,BC;
	
	public TwoD(int x, int y, int x2, int y2) {
		super(x, y);
		// TODO Auto-generated constructor stub
		this.x1=x;
		this.y1=y;
		this.x2=x2;
		this.y2=y2;
	}
	 public int getAB(){
    AB=(int) sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
    return AB;
	 }

}
