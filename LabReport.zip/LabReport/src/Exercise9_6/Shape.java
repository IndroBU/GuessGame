package Exercise9_6;

public class Shape {
  ///Instance Variable Declaration
	public int x;
	public int y;
	//Constractor Creting
	public Shape(int x, int y)
	{
		this.x=x;
		this.y=y;
	}
	//Set Method Creaing
	public void setX(int x)
	{
		this.x=x;
		
	}
	//Get Method Creating
	public int getX()
	{
		
		return x;
	}

	//Set Method Creaing
		public void setY(int y)
		{
			this.y=y;
			
		}
		//Get Method Creating
		public int getY()
		{
			
			return y;
		}
}
