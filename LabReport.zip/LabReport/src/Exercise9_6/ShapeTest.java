package Exercise9_6;

public class ShapeTest {
      public static void main(String[] orgs)
      {
    	  Square obj = new Square(5, 3, 5, 3, 5, 3, 5, 3);
    	  if(obj.getAB()==obj.getBC() && obj.getCD()==obj.getDA())
    	  {
    		  System.out.println("Yes, its a square");
    	  }
    	  else
    		  System.out.println("No, its not a square");
    	  Cube obj2= new Cube(5,5,5);
    	  System.out.println("Yes its a Cube: Area = "+obj2.getArea());
      }
}
