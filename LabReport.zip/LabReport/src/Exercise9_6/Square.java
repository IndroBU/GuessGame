package Exercise9_6;

import static java.lang.Math.sqrt;

public class Square extends TwoD {
    public int x2,y2,x3,y3,x4,y4;
    public int BC,CD,DA,CA,BD;
	public Square(int x, int y, int x2, int y2,int x3, int y3, int x4, int y4) {
		super(x, y, x2, y2);
		this.x2=x2;
		this.y2=y2;
		this.x3=x3;
		this.y3=y3;
		this.x4=x4;
		this.y4=y4;
		// TODO Auto-generated constructor stub
		
	}
	
	protected int getBC()
	{
		BC=(int) sqrt((x2-x3)*(x2-x3)+(y2-y3)*(y2-y3));
	    return BC;
	}
	
	public int getCD()
	{
		CD=(int) sqrt((x3-x4)*(x3-x4)+(y3-y4)*(y3-y4));
	    return CD;
	}
	
	public int getDA()
	{
		DA=(int) sqrt((x4-x1)*(x4-x1)+(y4-y1)*(y4-y1));
	    return DA;
	}
	
	public int getCA()
	{
		CA=(int) sqrt((x3-x1)*(x3-x1)+(y3-y1)*(y3-y1));
	    return CA;
	}

	public int getBD()
	{
		BD=(int) sqrt((x4-x2)*(x4-x2)+(y4-y2)*(y4-y2));
	    return BD;
	}


}
