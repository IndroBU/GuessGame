import java.util.Scanner;
public class GCD {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int x,y,m;
         while(sc.hasNextLine()){ 
    	   x=sc.nextInt();
    	   y=sc.nextInt();
    	   
    	   while(y!=0)
    	   {
    		   m=x%y;
    		   x=y;
    		   y=m;
    	   }
    	   
    	  System.out.println("GCD = "+x);
    	 
	       
	     
 
	      
       }

	}

}



