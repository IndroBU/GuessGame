package Exercise3_6;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
public class Test{
   public static void main(String args[])
   {
       Date todaysDate = new Date();
       DateFormat df3 = new SimpleDateFormat("dd-MM-yyyy");
       String str3 = df3.format(todaysDate);
      char a,b;
       
       a=str3.charAt(0);
    b=str3.charAt(1);
       String s1,s2,s3;
       StringBuilder sb = new StringBuilder();
       sb.append(a);
       sb.append(b);
       
       s1 = sb.toString();
       //System.out.println(s1);
       int Day= Integer.parseInt(s1);
       System.out.println(Day);
       
        a= str3.charAt(3);
        b=str3.charAt(4);
        StringBuilder sc =new StringBuilder();
        sc.append(a);
        sc.append(b);
        s2=sc.toString();
        //System.out.println(s2);
        int Month=Integer.parseInt(s2);
        System.out.println(Month);
        char c,d;
        a=str3.charAt(6);
        b=str3.charAt(7);
        c=str3.charAt(8);
        d=str3.charAt(9);
        StringBuilder sd = new StringBuilder();
        sd.append(a);
        sd.append(b); sd.append(c); sd.append(d);
        s3=sd.toString();
        int Year=Integer.parseInt(s3);
        System.out.println(Year);
    }
}

