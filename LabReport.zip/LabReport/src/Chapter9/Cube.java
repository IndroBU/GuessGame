package Chapter9;

public class Cube extends ThreeD {
   public double area,a;
 
   
	public Cube(int x,int y,int z) {
		super(x, y,z);
		// TODO Auto-generated constructor stub
		a=x;
		
	}
	   
	
	public double getArea()
	{
		
		area=a*a*a;
		return area;
	}
	

}