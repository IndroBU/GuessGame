package Chapter9;

public class ThreeD extends Shape {
   public double area,a;
   
	public ThreeD(int x,int y,int z) {
		super(x, y);
		// TODO Auto-generated constructor stub
		a=x;
		
	}
	/*
	public double getArea()
	{
		
		area=a*a*a;
		return area;
	}
	*/

}
