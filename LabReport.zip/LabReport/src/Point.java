
public class Point {
   private int distanceX, distanceY;
   private int x1,x2,y1,y2;
   public Point(int x1, int x2, int y1, int y2)
   {
	   this.x1=x1;
	   this.x2=x2;
	   this.y1=y1;
	   this.y2=y2;
	   setDistanceX();
	   setDistanceY();
   }
   private void setDistanceX()
   {
	   distanceX = x2-x1;
   }
   public int getDistanceX()
   {
	   return distanceX;
   }
   private void setDistanceY()
   {
	   distanceY =y2-y1;
   }
   public int getDistanceY()
   {
	   return distanceY;
   }
   
   
}