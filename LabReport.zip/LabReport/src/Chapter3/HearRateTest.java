package Chapter3;

public class HearRateTest {
	public static void main(String[] orgs)
	{
	    HeartRates obj = new HeartRates("Indrojit","Mondal","19-04-1994");
	    System.out.print(obj.FirstName);
	    System.out.println(" "+obj.LastName);
	    System.out.println("Age: "+obj.AgeCalCulator());
	    System.out.println("MaximumHeartRate: "+obj.MaximumHearRate());
	    System.out.println("TargetHeartRate: "+obj.TargetHeartRate1()+" To "+obj.TargetHeartRate2());
	    
	} 

}
