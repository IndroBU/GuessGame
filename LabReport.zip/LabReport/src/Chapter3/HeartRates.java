 package Chapter3;
import java.util.Scanner;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
public class HeartRates {
	
	public String FirstName;
	public String LastName;
	public String BirthDate;
	public String strTodaysDate;
	  public int Age;
    public HeartRates(String FirstName,String LastName, String BirthDate)
    {
    	this.FirstName=FirstName;
    	this.LastName=LastName;
    	this.BirthDate=BirthDate;
    }
	
	public int AgeCalCulator()
	{
		
		Date todaysDate = new Date();
	       DateFormat df3 = new SimpleDateFormat("dd-MM-yyyy");
	       String str3 = df3.format(todaysDate);
	      char a,b,c,d;
	       
	       a=str3.charAt(0);
	    b=str3.charAt(1);
	       String s1,s2,s3;
	       StringBuilder sb = new StringBuilder();
	       sb.append(a);
	       sb.append(b);
	       
	       s1 = sb.toString();
	       //System.out.println(s1);
	       int Day= Integer.parseInt(s1);
	       //System.out.println(Day);
	       
	        a= str3.charAt(3);
	        b=str3.charAt(4);
	        StringBuilder sc =new StringBuilder();
	        sc.append(a);
	        sc.append(b);
	        s2=sc.toString();
	        //System.out.println(s2);
	        int Month=Integer.parseInt(s2);
	       //System.out.println(Month);
	        //char c,d;
	        a=str3.charAt(6);
	        b=str3.charAt(7);
	        c=str3.charAt(8);
	        d=str3.charAt(9);
	        StringBuilder sd = new StringBuilder();
	        sd.append(a);
	        sd.append(b); sd.append(c); sd.append(d);
	        s3=sd.toString();
	        int Year=Integer.parseInt(s3);
	        //System.out.println(Year);
	        //System.out.println(BirthDate);
	        a=BirthDate.charAt(0);
		    b=BirthDate.charAt(1);
		       //String s1,s2,s3;
		       StringBuilder sb1 = new StringBuilder();
		       sb1.append(a);
		       sb1.append(b);
		       
		       s1 = sb1.toString();
		       //System.out.println(s1);
		       int Day1= Integer.parseInt(s1);
		      //System.out.println(Day1);
		       
		        a= BirthDate.charAt(3);
		        b=BirthDate.charAt(4);
		        StringBuilder sc1 =new StringBuilder();
		        sc1.append(a);
		        sc1.append(b);
		        s2=sc1.toString();
		        //System.out.println(s2);
		        int Month1=Integer.parseInt(s2);
		        
		      
		      /// System.out.println(Month1);
		     
		        a=BirthDate.charAt(6);
		        b=BirthDate.charAt(7);
		        c=BirthDate.charAt(8); 
		        d=BirthDate.charAt(9);
		        StringBuilder sd1 = new StringBuilder();
		        sd1.append(a);
		        sd1.append(b); sd1.append(c); sd1.append(d);
		        s3=sd1.toString();
		        int Year1=Integer.parseInt(s3);
		       // System.out.println(Year1);
		      
		       if(Day<Day1){
		            Day=Day+30;
		            Month1=Month1+1;
		        }
		        if(Month<Month1)
		        {
		            
		            Year1++;
		        }
		         //System.out.println(Year+" "+Year1);
		        Age = Year-Year1;
		        this.Age=Age;
		       // System.out.println(Age);
		         return Age;   
	        
	    }
	
	    public int MaximumHearRate()
	    {
	    
	      return 220-Age;	
	    	
	    }
	    
	    public double TargetHeartRate1()
	    {
	    	 return MaximumHearRate()*0.50;
	    }
	    public double TargetHeartRate2()
	    {
	    	 return MaximumHearRate()*0.85;
	    }
	    
	
}
