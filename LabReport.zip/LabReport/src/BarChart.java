
import java.util.Scanner;

public class BarChart {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int i,j,number;
       Scanner Sc =new Scanner(System.in);
       for(i=1; i<=5; i++)
       {
    	   System.out.print("*\n");
       }
       //System.out.print(" ");
      for(j=1; j<=5; j++){
       for(i=1; i<=1; i++)
       {
    	   System.out.printf("%s"," ");
    	   
       }
       System.out.println("*\n");
       
      }
       System.out.print(" ");       
       for(i=1; i<=7; i++)
       {
    	   System.out.printf("*\n");
       }
       
       
       System.exit(0);
       
	}

}
